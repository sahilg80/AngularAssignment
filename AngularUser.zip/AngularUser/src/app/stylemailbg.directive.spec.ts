import { StylemailbgDirective } from './stylemailbg.directive';

describe('StylemailbgDirective', () => {
  it('should create an instance', () => {
    const directive = new StylemailbgDirective();
    expect(directive).toBeTruthy();
  });
});
