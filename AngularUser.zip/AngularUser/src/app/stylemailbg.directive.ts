import { Directive,ElementRef,HostListener } from '@angular/core';

@Directive({
  selector: '[appStylemailbg]'
})
export class StylemailbgDirective {

  constructor(private el:ElementRef) {
  } 
  
  @HostListener('mouseenter') onMouseEnter() {
    this.highlight('brown');
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.highlight('');
  }

  private highlight(color:String){
    this.el.nativeElement.style.backgroundColor = color;
  }

}
